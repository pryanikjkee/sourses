$(function(){

var countDownDate = new Date("Sep 5, 2018 15:37:25").getTime();


var x = setInterval(function() {


  var now = new Date().getTime();


  var distance = countDownDate - now;


  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);


  document.querySelector('.counter-day span').innerHTML = days;
  document.querySelector('.counter-hour span').innerHTML = hours;
  document.querySelector('.counter-minute span ').innerHTML = minutes;
  document.querySelector('.counter-seconds span').innerHTML = seconds;
 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
})
window.onload= function(){
  document.querySelectorAll('.layer__item')[0].classList.add('anim');
  document.querySelectorAll('.layer__item')[1].classList.add('anim');
  document.querySelectorAll('.layer__item')[2].classList.add('anim');
  document.querySelectorAll('.layer__item')[3].classList.add('anim');
  document.querySelectorAll('.layer__item')[4].classList.add('anim');
  setTimeout(() => {
    document.querySelectorAll('.layer__item')[0].classList.remove('anim');
    document.querySelectorAll('.layer__item')[0].classList.add('animafter');
    document.querySelectorAll('.layer__item')[1].classList.remove('anim');
    document.querySelectorAll('.layer__item')[1].classList.add('animafter');
    document.querySelectorAll('.layer__item')[2].classList.remove('anim');
    document.querySelectorAll('.layer__item')[2].classList.add('animafter');
    document.querySelectorAll('.layer__item')[3].classList.remove('anim');
    document.querySelectorAll('.layer__item')[3].classList.add('animafter');
    document.querySelectorAll('.layer__item')[4].classList.remove('anim');
    document.querySelectorAll('.layer__item')[4].classList.add('animafter');
  }, 2800);

}